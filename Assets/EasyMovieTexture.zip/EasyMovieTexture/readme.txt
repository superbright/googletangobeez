EasyMovieTexture For Android

EasyMovieTexture is using Android MediaPlayer Class.

Android MediaPlayer supports all formats are available.

Streaming services are also supported.(Internet Access option is checked, the streaming service )

From Android version 4.0 or later are supported.

And the this demo movie licensing. (c) copyright 2006, Blender Foundation / Netherlands Media Art Institute / www.elephantsdream.org
http://orange.blender.org/blog/creative-commons-license-2/


Editor On the Android Platform API can not be used ....

Only works with Android devices.



iOS 

The original source of the following site.( iOS Source )
(https://github.com/unity3d-jp/iOS-VideoPlayerPlugin)

Created by modifying the source.


